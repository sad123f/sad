import { io } from 'socket.io-client';

export const socket = io('https://your-backend-url.com', {
  autoConnect: true,
  transports: ['websocket'],
});