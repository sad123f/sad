import { Peer } from 'peerjs';

let peer: Peer | null = null;

export const getPeer = () => {
  if (!peer) {
    peer = new Peer(undefined, {
      host: 'your-peerjs-server.com',
      port: 443,
      secure: true
    });
  }
  return peer;
};

export const closePeer = () => {
  if (peer) {
    peer.destroy();
    peer = null;
  }
};