export type DrawingCategory = 
  | 'construction'
  | 'architectural'
  | 'electrical'
  | 'mechanical'
  | 'survey';

export interface Drawing {
  id: string;
  name: string;
  category: DrawingCategory;
  url: string;
  uploadedBy: string;
  uploadedAt: Date;
  size: number;
}

export const DRAWING_CATEGORIES: Record<DrawingCategory, string> = {
  construction: 'لوحات الإنشاءات',
  architectural: 'لوحات المعمارية',
  electrical: 'لوحات الكهربائية',
  mechanical: 'لوحات الميكانيكا',
  survey: 'لوحات الرفع المساحي',
};