export interface Project {
  id: string;
  title: string;
  description: string;
  location: string;
  startDate: Date;
  endDate: Date;
  status: 'active' | 'completed' | 'pending';
  members: string[];
  coordinates?: [number, number];
  image: string;
}

export interface ProjectFormData extends Omit<Project, 'id' | 'status'> {
  status: string;
}