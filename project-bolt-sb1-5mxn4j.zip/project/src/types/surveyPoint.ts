export interface SurveyPoint {
  id: string;
  pointNumber: string;
  easting: number;
  northing: number;
  elevation: number;
  notes: string;
}

export interface SurveyPointFormData extends Omit<SurveyPoint, 'id'> {}