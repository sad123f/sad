import React, { useState, useEffect } from 'react';
import { Dialog } from '@headlessui/react';
import { X, Video, Mic } from 'lucide-react';
import ChatMessage from '../components/chat/ChatMessage';
import ChatInput from '../components/chat/ChatInput';
import VideoCall from '../components/video/VideoCall';
import { socket } from '../lib/socket';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'other';
  timestamp: Date;
  attachments?: {
    id: string;
    type: 'file' | 'image' | 'audio' | 'video';
    url: string;
    name: string;
    size: string;
  }[];
  isVideoCall?: boolean;
  isAudioCall?: boolean;
}

export default function Chat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isCallActive, setIsCallActive] = useState(false);
  const [callType, setCallType] = useState<'video' | 'audio' | null>(null);
  const [activeRoomId, setActiveRoomId] = useState<string | null>(null);

  useEffect(() => {
    socket.on('receive-message', (message: Message) => {
      setMessages(prev => [...prev, message]);
    });

    socket.on('call-started', ({ roomId, type }) => {
      setActiveRoomId(roomId);
      setCallType(type);
      setIsCallActive(true);
    });

    return () => {
      socket.off('receive-message');
      socket.off('call-started');
    };
  }, []);

  const handleSendMessage = (text: string, files?: File[]) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      text,
      sender: 'user',
      timestamp: new Date(),
      attachments: files?.map((file, index) => ({
        id: `${Date.now()}-${index}`,
        type: 'file',
        url: URL.createObjectURL(file),
        name: file.name,
        size: `${(file.size / 1024).toFixed(1)} KB`,
      })),
    };

    setMessages([...messages, newMessage]);
    socket.emit('send-message', newMessage);
  };

  const handleStartVideoCall = () => {
    const roomId = Date.now().toString();
    setActiveRoomId(roomId);
    setCallType('video');
    setIsCallActive(true);
    
    const callMessage: Message = {
      id: Date.now().toString(),
      text: 'تم بدء مكالمة فيديو',
      sender: 'user',
      timestamp: new Date(),
      isVideoCall: true,
    };
    
    setMessages([...messages, callMessage]);
    socket.emit('start-call', { roomId, type: 'video' });
  };

  const handleStartAudioCall = () => {
    const roomId = Date.now().toString();
    setActiveRoomId(roomId);
    setCallType('audio');
    setIsCallActive(true);
    
    const callMessage: Message = {
      id: Date.now().toString(),
      text: 'تم بدء مكالمة صوتية',
      sender: 'user',
      timestamp: new Date(),
      isAudioCall: true,
    };
    
    setMessages([...messages, callMessage]);
    socket.emit('start-call', { roomId, type: 'audio' });
  };

  const handleEndCall = () => {
    setIsCallActive(false);
    setCallType(null);
    setActiveRoomId(null);
    socket.emit('end-call', { roomId: activeRoomId });
  };

  return (
    <div className="h-[calc(100vh-2rem)] flex flex-col">
      <div className="bg-white p-4 rounded-lg shadow-sm mb-4">
        <h2 className="text-xl font-semibold">الدردشة</h2>
      </div>

      <div className="flex-1 bg-white rounded-lg shadow-sm overflow-hidden flex flex-col">
        <div className="flex-1 overflow-y-auto p-4">
          {messages.map((message) => (
            <ChatMessage key={message.id} {...message} />
          ))}
        </div>

        <ChatInput
          onSendMessage={handleSendMessage}
          onStartVideoCall={handleStartVideoCall}
          onStartAudioCall={handleStartAudioCall}
        />
      </div>

      {isCallActive && activeRoomId && (
        <VideoCall
          roomId={activeRoomId}
          onClose={handleEndCall}
        />
      )}
    </div>
  );
}