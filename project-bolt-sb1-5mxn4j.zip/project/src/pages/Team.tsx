import React, { useState } from 'react';
import { Mail, Phone, MapPin, Plus, UserPlus, Trash2, Edit2 } from 'lucide-react';
import { Dialog } from '@headlessui/react';
import toast from 'react-hot-toast';

interface TeamMember {
  id: number;
  name: string;
  role: string;
  email: string;
  phone: string;
  location: string;
  avatar: string;
  permissions: ('admin' | 'member' | 'guest')[];
  projects: string[];
}

const initialTeamMembers: TeamMember[] = [
  {
    id: 1,
    name: 'محمد أحمد',
    role: 'مهندس مساحة رئيسي',
    email: 'mohammed@example.com',
    phone: '+966 50 123 4567',
    location: 'الرياض',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=100&h=100',
    permissions: ['admin'],
    projects: ['مشروع الرياض الشمالية', 'تطوير منطقة القصيم'],
  },
  {
    id: 2,
    name: 'سارة خالد',
    role: 'مخطط مشاريع',
    email: 'sara@example.com',
    phone: '+966 55 987 6543',
    location: 'جدة',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=100&h=100',
    permissions: ['member'],
    projects: ['مشروع الرياض الشمالية'],
  },
  {
    id: 3,
    name: 'عبدالله محمد',
    role: 'مساح ميداني',
    email: 'abdullah@example.com',
    phone: '+966 54 456 7890',
    location: 'الدمام',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=100&h=100',
    permissions: ['member'],
    projects: ['تطوير منطقة القصيم'],
  },
];

const availableProjects = [
  'مشروع الرياض الشمالية',
  'تطوير منطقة القصيم',
  'مشروع وادي الدواسر',
];

export default function Team() {
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>(initialTeamMembers);
  const [isAddMemberOpen, setIsAddMemberOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<TeamMember | null>(null);
  const [newMember, setNewMember] = useState<Partial<TeamMember>>({
    name: '',
    role: '',
    email: '',
    phone: '',
    location: '',
    permissions: ['member'],
    projects: [],
  });

  const handleAddMember = () => {
    if (!newMember.name || !newMember.email) {
      toast.error('يرجى ملء جميع الحقول المطلوبة');
      return;
    }

    const member: TeamMember = {
      id: Date.now(),
      name: newMember.name,
      role: newMember.role || '',
      email: newMember.email,
      phone: newMember.phone || '',
      location: newMember.location || '',
      avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(newMember.name)}&background=0D9488&color=fff`,
      permissions: newMember.permissions || ['member'],
      projects: newMember.projects || [],
    };

    setTeamMembers([...teamMembers, member]);
    setIsAddMemberOpen(false);
    toast.success('تم إضافة العضو بنجاح');
    setNewMember({
      name: '',
      role: '',
      email: '',
      phone: '',
      location: '',
      permissions: ['member'],
      projects: [],
    });
  };

  const handleEditMember = (member: TeamMember) => {
    setEditingMember(member);
    setNewMember(member);
    setIsAddMemberOpen(true);
  };

  const handleUpdateMember = () => {
    if (!editingMember) return;

    const updatedMembers = teamMembers.map((member) =>
      member.id === editingMember.id ? { ...member, ...newMember } : member
    );

    setTeamMembers(updatedMembers);
    setIsAddMemberOpen(false);
    setEditingMember(null);
    toast.success('تم تحديث بيانات العضو بنجاح');
  };

  const handleDeleteMember = (id: number) => {
    if (confirm('هل أنت متأكد من حذف هذا العضو؟')) {
      setTeamMembers(teamMembers.filter((member) => member.id !== id));
      toast.success('تم حذف العضو بنجاح');
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold">فريق العمل</h2>
          <button
            onClick={() => {
              setEditingMember(null);
              setNewMember({
                name: '',
                role: '',
                email: '',
                phone: '',
                location: '',
                permissions: ['member'],
                projects: [],
              });
              setIsAddMemberOpen(true);
            }}
            className="flex items-center space-x-2 space-x-reverse bg-emerald-500 text-white px-4 py-2 rounded-lg hover:bg-emerald-600 transition-colors"
          >
            <UserPlus className="w-5 h-5" />
            <span>إضافة عضو</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {teamMembers.map((member) => (
            <div key={member.id} className="bg-white border rounded-lg p-6 hover:shadow-md transition-shadow">
              <div className="flex items-center space-x-4 space-x-reverse mb-4">
                <img
                  src={member.avatar}
                  alt={member.name}
                  className="w-16 h-16 rounded-full object-cover"
                />
                <div className="flex-1">
                  <h3 className="font-semibold text-lg">{member.name}</h3>
                  <p className="text-emerald-600">{member.role}</p>
                </div>
                <div className="flex space-x-2 space-x-reverse">
                  <button
                    onClick={() => handleEditMember(member)}
                    className="p-2 text-gray-500 hover:text-emerald-500 transition-colors"
                  >
                    <Edit2 className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => handleDeleteMember(member.id)}
                    className="p-2 text-gray-500 hover:text-red-500 transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="space-y-2 text-gray-600">
                <div className="flex items-center space-x-2 space-x-reverse">
                  <Mail className="w-4 h-4" />
                  <span>{member.email}</span>
                </div>
                <div className="flex items-center space-x-2 space-x-reverse">
                  <Phone className="w-4 h-4" />
                  <span>{member.phone}</span>
                </div>
                <div className="flex items-center space-x-2 space-x-reverse">
                  <MapPin className="w-4 h-4" />
                  <span>{member.location}</span>
                </div>
              </div>

              <div className="mt-4">
                <div className="text-sm font-medium text-gray-700 mb-2">المشاريع:</div>
                <div className="flex flex-wrap gap-2">
                  {member.projects.map((project) => (
                    <span
                      key={project}
                      className="bg-emerald-100 text-emerald-800 text-sm px-2 py-1 rounded"
                    >
                      {project}
                    </span>
                  ))}
                </div>
              </div>

              <div className="mt-4">
                <div className="text-sm font-medium text-gray-700 mb-2">الصلاحيات:</div>
                <div className="flex flex-wrap gap-2">
                  {member.permissions.map((permission) => (
                    <span
                      key={permission}
                      className="bg-gray-100 text-gray-800 text-sm px-2 py-1 rounded"
                    >
                      {permission === 'admin' ? 'مشرف' : permission === 'member' ? 'عضو' : 'ضيف'}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <Dialog open={isAddMemberOpen} onClose={() => setIsAddMemberOpen(false)} className="relative z-50">
        <div className="fixed inset-0 bg-black/30" aria-hidden="true" />
        <div className="fixed inset-0 flex items-center justify-center p-4">
          <Dialog.Panel className="bg-white rounded-lg p-6 max-w-md w-full">
            <Dialog.Title className="text-lg font-semibold mb-4">
              {editingMember ? 'تعديل بيانات العضو' : 'إضافة عضو جديد'}
            </Dialog.Title>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">الاسم</label>
                <input
                  type="text"
                  value={newMember.name}
                  onChange={(e) => setNewMember({ ...newMember, name: e.target.value })}
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">الدور</label>
                <input
                  type="text"
                  value={newMember.role}
                  onChange={(e) => setNewMember({ ...newMember, role: e.target.value })}
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">البريد الإلكتروني</label>
                <input
                  type="email"
                  value={newMember.email}
                  onChange={(e) => setNewMember({ ...newMember, email: e.target.value })}
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">رقم الهاتف</label>
                <input
                  type="tel"
                  value={newMember.phone}
                  onChange={(e) => setNewMember({ ...newMember, phone: e.target.value })}
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">الموقع</label>
                <input
                  type="text"
                  value={newMember.location}
                  onChange={(e) => setNewMember({ ...newMember, location: e.target.value })}
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">الصلاحيات</label>
                <select
                  multiple
                  value={newMember.permissions}
                  onChange={(e) => {
                    const selected = Array.from(e.target.selectedOptions, (option) => option.value as 'admin' | 'member' | 'guest');
                    setNewMember({ ...newMember, permissions: selected });
                  }}
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="admin">مشرف</option>
                  <option value="member">عضو</option>
                  <option value="guest">ضيف</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">المشاريع</label>
                <select
                  multiple
                  value={newMember.projects}
                  onChange={(e) => {
                    const selected = Array.from(e.target.selectedOptions, (option) => option.value);
                    setNewMember({ ...newMember, projects: selected });
                  }}
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
                >
                  {availableProjects.map((project) => (
                    <option key={project} value={project}>
                      {project}
                    </option>
                  ))}
                </select>
              </div>

              <button
                onClick={editingMember ? handleUpdateMember : handleAddMember}
                className="w-full bg-emerald-500 text-white py-2 rounded-lg hover:bg-emerald-600 transition-colors"
              >
                {editingMember ? 'تحديث' : 'إضافة'}
              </button>
            </div>
          </Dialog.Panel>
        </div>
      </Dialog>
    </div>
  );
}