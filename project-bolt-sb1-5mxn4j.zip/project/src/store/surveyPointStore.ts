import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { SurveyPoint, SurveyPointFormData } from '../types/surveyPoint';

interface SurveyPointState {
  points: SurveyPoint[];
  addPoint: (point: SurveyPointFormData) => void;
  updatePoint: (id: string, point: SurveyPointFormData) => void;
  deletePoint: (id: string) => void;
}

export const useSurveyPointStore = create<SurveyPointState>()(
  persist(
    (set) => ({
      points: [],
      addPoint: (pointData) => set((state) => ({
        points: [...state.points, {
          ...pointData,
          id: Date.now().toString(),
        }],
      })),
      updatePoint: (id, pointData) => set((state) => ({
        points: state.points.map((point) =>
          point.id === id ? { ...pointData, id } : point
        ),
      })),
      deletePoint: (id) => set((state) => ({
        points: state.points.filter((point) => point.id !== id),
      })),
    }),
    {
      name: 'survey-points-storage',
    }
  )
);