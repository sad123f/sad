import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Drawing, DrawingCategory } from '../types/drawing';

interface DrawingState {
  drawings: Drawing[];
  addDrawing: (drawing: Omit<Drawing, 'id' | 'uploadedAt'>) => void;
  deleteDrawing: (id: string) => void;
  getDrawingsByCategory: (category: DrawingCategory) => Drawing[];
}

export const useDrawingStore = create<DrawingState>()(
  persist(
    (set, get) => ({
      drawings: [],
      addDrawing: (drawingData) => set((state) => ({
        drawings: [...state.drawings, {
          ...drawingData,
          id: Date.now().toString(),
          uploadedAt: new Date(),
        }],
      })),
      deleteDrawing: (id) => set((state) => ({
        drawings: state.drawings.filter((drawing) => drawing.id !== id),
      })),
      getDrawingsByCategory: (category) => 
        get().drawings.filter((drawing) => drawing.category === category),
    }),
    {
      name: 'drawings-storage',
    }
  )
);