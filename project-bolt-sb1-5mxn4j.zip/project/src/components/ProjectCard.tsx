import React from 'react';
import { Calendar, Users, MapPin } from 'lucide-react';

interface ProjectCardProps {
  title: string;
  location: string;
  date: string;
  members: number;
  image: string;
}

export default function ProjectCard({ title, location, date, members, image }: ProjectCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <img src={image} alt={title} className="w-full h-48 object-cover" />
      <div className="p-5">
        <h3 className="text-xl font-semibold mb-3">{title}</h3>
        <div className="flex items-center text-gray-600 mb-2">
          <MapPin className="w-4 h-4 ml-2" />
          <span className="text-sm">{location}</span>
        </div>
        <div className="flex items-center text-gray-600 mb-2">
          <Calendar className="w-4 h-4 ml-2" />
          <span className="text-sm">{date}</span>
        </div>
        <div className="flex items-center text-gray-600">
          <Users className="w-4 h-4 ml-2" />
          <span className="text-sm">{members} أعضاء</span>
        </div>
      </div>
    </div>
  );
}