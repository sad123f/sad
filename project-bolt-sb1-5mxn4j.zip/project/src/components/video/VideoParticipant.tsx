import React, { useRef, useEffect } from 'react';
import { User, MicOff, CameraOff } from 'lucide-react';

interface Participant {
  id: string;
  name: string;
  stream?: MediaStream;
  audio: boolean;
  video: boolean;
}

interface VideoParticipantProps {
  participant: Participant;
}

export default function VideoParticipant({ participant }: VideoParticipantProps) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current && participant.stream) {
      videoRef.current.srcObject = participant.stream;
    }
  }, [participant.stream]);

  return (
    <div className="relative bg-gray-800 rounded-lg overflow-hidden">
      {participant.stream && participant.video ? (
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted={participant.id === 'local'}
          className="w-full h-full object-cover"
        />
      ) : (
        <div className="w-full h-full flex items-center justify-center">
          <User className="w-20 h-20 text-gray-500" />
        </div>
      )}

      <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/70 to-transparent">
        <div className="flex items-center justify-between">
          <span className="text-white font-medium">{participant.name}</span>
          <div className="flex items-center space-x-2 space-x-reverse">
            {!participant.audio && (
              <div className="p-1.5 bg-red-500 rounded-full">
                <MicOff className="w-4 h-4 text-white" />
              </div>
            )}
            {!participant.video && (
              <div className="p-1.5 bg-red-500 rounded-full">
                <CameraOff className="w-4 h-4 text-white" />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}