import React from 'react';
import { Camera, CameraOff, Mic, MicOff, PhoneOff, Users } from 'lucide-react';
import { useVideoCall } from '../../hooks/useVideoCall';
import VideoParticipant from './VideoParticipant';
import toast from 'react-hot-toast';

interface VideoCallProps {
  roomId: string;
  onClose: () => void;
}

export default function VideoCall({ roomId, onClose }: VideoCallProps) {
  const {
    participants,
    isConnecting,
    error,
    toggleAudio,
    toggleVideo,
    cleanup
  } = useVideoCall(roomId);

  const localParticipant = participants.find(p => p.id === 'local');
  const isAudioEnabled = localParticipant?.audio ?? true;
  const isVideoEnabled = localParticipant?.video ?? true;

  const handleClose = () => {
    cleanup();
    onClose();
  };

  if (error) {
    toast.error(error);
    handleClose();
    return null;
  }

  if (isConnecting) {
    return (
      <div className="fixed inset-0 bg-gray-900 flex items-center justify-center">
        <div className="text-white text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-white border-t-transparent mx-auto mb-4"></div>
          <p>جاري الاتصال...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-gray-900 flex flex-col">
      <div className="p-4 flex justify-between items-center bg-gray-800">
        <div className="flex items-center space-x-3 space-x-reverse">
          <Users className="w-5 h-5 text-white" />
          <span className="text-white">{participants.length} مشاركين</span>
        </div>
        <div className="flex items-center space-x-4 space-x-reverse">
          <button
            onClick={toggleAudio}
            className={`p-3 rounded-full ${
              isAudioEnabled ? 'bg-gray-600' : 'bg-red-500'
            }`}
          >
            {isAudioEnabled ? (
              <Mic className="w-5 h-5 text-white" />
            ) : (
              <MicOff className="w-5 h-5 text-white" />
            )}
          </button>
          <button
            onClick={toggleVideo}
            className={`p-3 rounded-full ${
              isVideoEnabled ? 'bg-gray-600' : 'bg-red-500'
            }`}
          >
            {isVideoEnabled ? (
              <Camera className="w-5 h-5 text-white" />
            ) : (
              <CameraOff className="w-5 h-5 text-white" />
            )}
          </button>
          <button
            onClick={handleClose}
            className="p-3 rounded-full bg-red-500"
          >
            <PhoneOff className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>

      <div className="flex-1 p-4">
        <div className={`grid gap-4 h-full ${
          participants.length <= 1 ? 'grid-cols-1' :
          participants.length <= 4 ? 'grid-cols-2' :
          'grid-cols-3'
        }`}>
          {participants.map((participant) => (
            <VideoParticipant
              key={participant.id}
              participant={participant}
            />
          ))}
        </div>
      </div>
    </div>
  );
}