import React from 'react';
import { Plus } from 'lucide-react';
import ProjectCard from './ProjectCard';
import { Project } from '../../types/project';

interface ProjectListProps {
  projects: Project[];
  onAddProject: () => void;
  onEditProject: (project: Project) => void;
  onDeleteProject: (projectId: string) => void;
}

export default function ProjectList({
  projects,
  onAddProject,
  onEditProject,
  onDeleteProject,
}: ProjectListProps) {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">المشاريع النشطة</h2>
        <button
          onClick={onAddProject}
          className="flex items-center space-x-2 space-x-reverse bg-emerald-500 text-white px-4 py-2 rounded-lg hover:bg-emerald-600 transition-colors"
        >
          <Plus className="w-5 h-5" />
          <span>إضافة مشروع</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((project) => (
          <ProjectCard
            key={project.id}
            project={project}
            onEdit={() => onEditProject(project)}
            onDelete={() => onDeleteProject(project.id)}
          />
        ))}
      </div>
    </div>
  );
}