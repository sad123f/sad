import React from 'react';
import { Calendar, Users, MapPin, Edit2, Trash2 } from 'lucide-react';
import { Project } from '../../types/project';
import { format } from 'date-fns';
import { arSA } from 'date-fns/locale';

interface ProjectCardProps {
  project: Project;
  onEdit: () => void;
  onDelete: () => void;
}

export default function ProjectCard({ project, onEdit, onDelete }: ProjectCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <img src={project.image} alt={project.title} className="w-full h-48 object-cover" />
      <div className="p-5">
        <div className="flex justify-between items-start mb-3">
          <h3 className="text-xl font-semibold">{project.title}</h3>
          <div className="flex space-x-2 space-x-reverse">
            <button
              onClick={onEdit}
              className="p-2 text-gray-500 hover:text-emerald-500 transition-colors"
            >
              <Edit2 className="w-5 h-5" />
            </button>
            <button
              onClick={onDelete}
              className="p-2 text-gray-500 hover:text-red-500 transition-colors"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          </div>
        </div>
        
        <div className="flex items-center text-gray-600 mb-2">
          <MapPin className="w-4 h-4 ml-2" />
          <span className="text-sm">{project.location}</span>
        </div>
        
        <div className="flex items-center text-gray-600 mb-2">
          <Calendar className="w-4 h-4 ml-2" />
          <span className="text-sm">
            {format(project.startDate, 'dd MMM yyyy', { locale: arSA })}
          </span>
        </div>
        
        <div className="flex items-center text-gray-600">
          <Users className="w-4 h-4 ml-2" />
          <span className="text-sm">{project.members.length} أعضاء</span>
        </div>

        <div className="mt-4">
          <span className={`inline-block px-3 py-1 rounded-full text-sm ${
            project.status === 'active' ? 'bg-emerald-100 text-emerald-800' :
            project.status === 'completed' ? 'bg-blue-100 text-blue-800' :
            'bg-yellow-100 text-yellow-800'
          }`}>
            {project.status === 'active' ? 'نشط' :
             project.status === 'completed' ? 'مكتمل' : 'معلق'}
          </span>
        </div>
      </div>
    </div>
  );
}