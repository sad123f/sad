import React from 'react';
import { FileText, Trash2, Download } from 'lucide-react';
import { Drawing } from '../../types/drawing';
import { format } from 'date-fns';
import { arSA } from 'date-fns/locale';

interface DrawingListProps {
  drawings: Drawing[];
  onDelete: (id: string) => void;
  isAdmin: boolean;
}

export default function DrawingList({
  drawings,
  onDelete,
  isAdmin,
}: DrawingListProps) {
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {drawings.map((drawing) => (
        <div key={drawing.id} className="bg-white p-4 rounded-lg shadow-sm">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-3 space-x-reverse">
              <FileText className="w-10 h-10 text-emerald-500" />
              <div>
                <h4 className="font-medium">{drawing.name}</h4>
                <p className="text-sm text-gray-500">
                  {formatFileSize(drawing.size)}
                </p>
              </div>
            </div>
            <div className="flex space-x-2 space-x-reverse">
              <a
                href={drawing.url}
                download
                className="p-2 text-blue-500 hover:text-blue-600"
              >
                <Download className="w-5 h-5" />
              </a>
              {isAdmin && (
                <button
                  onClick={() => onDelete(drawing.id)}
                  className="p-2 text-red-500 hover:text-red-600"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              )}
            </div>
          </div>
          
          <div className="mt-4 text-sm text-gray-500">
            <p>تم الرفع بواسطة: {drawing.uploadedBy}</p>
            <p>
              تاريخ الرفع: {format(drawing.uploadedAt, 'dd MMM yyyy', { locale: arSA })}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}