import React from 'react';
import { Edit2, Trash2 } from 'lucide-react';
import { SurveyPoint } from '../../types/surveyPoint';

interface SurveyPointListProps {
  points: SurveyPoint[];
  onEdit: (point: SurveyPoint) => void;
  onDelete: (id: string) => void;
  isAdmin: boolean;
}

export default function SurveyPointList({
  points,
  onEdit,
  onDelete,
  isAdmin,
}: SurveyPointListProps) {
  return (
    <tbody>
      {points.map((point) => (
        <tr key={point.id} className="border-b">
          <td className="px-4 py-3">{point.pointNumber}</td>
          <td className="px-4 py-3">{point.easting}</td>
          <td className="px-4 py-3">{point.northing}</td>
          <td className="px-4 py-3">{point.elevation}</td>
          <td className="px-4 py-3">{point.notes}</td>
          {isAdmin && (
            <td className="px-4 py-3">
              <div className="flex space-x-2 space-x-reverse">
                <button
                  onClick={() => onEdit(point)}
                  className="p-2 text-blue-500 hover:text-blue-600"
                >
                  <Edit2 className="w-5 h-5" />
                </button>
                <button
                  onClick={() => onDelete(point.id)}
                  className="p-2 text-red-500 hover:text-red-600"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </td>
          )}
        </tr>
      ))}
    </tbody>
  );
}